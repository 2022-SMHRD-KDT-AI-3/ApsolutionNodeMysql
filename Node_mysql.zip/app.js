const express = require("express");
const app = express();
const bodyparser = require("body-parser");
const ejs = require("ejs");


const session = require("express-session"); 
const session_mysql_save = require("express-mysql-session");


// DB연결
let db_Apple = {
    host : 'project-db-stu.ddns.net', 
    user : 'applecareplus',
    password : '1234',
    port : '3307',
    database : 'applecareplus'
}


let s_m_s = new session_mysql_save(db_Apple);


app.use(session({
    secret : "smart",
    resave : false,
    saveUninitialized : true,
    store : s_m_s
}))


/*app.use(function(req, res, next) {

    console.log('첫 번째 미들웨어 호출 됨');
    var approve ={'approve_id':'NO','approve_pw':'NO'};


    var paramId = req.body.id;
    var paramPassword = req.body.password;
    console.log('id : '+paramId+'  pw : '+paramPassword);

    //아이디 일치여부 flag json 데이터입니다.
    if(paramId == 'test01') approve.approve_id = 'OK';
    if(paramPassword == '123') approve.approve_pw = 'OK';

    res.send(approve);

});*/

//라우터 실행
let startRouter = require('./routes/home');
let UploadRouter = require('./routes/ImgUpload');


// 경로지정
app.use(express.static("./public"));
// app.use(express.static("./uploads"));

app.set("view engine","ejs")




//
app.use(bodyparser.json());
app.use(bodyparser.urlencoded({extended:false}));

app.use('/member', require('./routes/member'));
app.use('/home', startRouter);
app.use('/upload', UploadRouter);

app.listen(3000, function(){
    console.log('start! server!');
});
