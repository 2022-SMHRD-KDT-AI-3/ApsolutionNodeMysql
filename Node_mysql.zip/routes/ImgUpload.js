const { request } = require("express");  
const express = require('express');
const multer = require("multer");
const router = express.Router();
//const multerS3 = require('multer-s3');


// aws 연결
// const aws = require('aws-');
// const s3 = new aws.s3({

// })

const path = require("path");
var fs = require('fs');



//사진 업로드
var _storage = multer.diskStorage({
    destination: function(req,file,cb){cb(null,'public/img/');},
    filename:function(req, file, cb){
        const ext = path.extname(file.originalname);
        const FileName = file.originalname+"_"+Date.now()+ext;
        cb(null, FileName);
    }
})

var upload = multer({storage: _storage});

router.post("/", upload.single('img'),(req,res)=>{
    try {
        res.send({
            message:"Upload_Success",
            status:'Success',
            data:{
                files:req.files
            }
        })
    } catch (error) {
        res.send({
            message:"Upload_Error",
            status:"Fail"

        })
    }

});


// router.post('/', upload.single('img'), function(req,res){ 
//     // const creator_id =req.body.creator_id;
//     // const title = req.body.title;
//     // const content = req.body.content;
//     // const image = '/img/${req.file.filename}';
//     // const datas = []
//     res.json({url:"a"});
//     console.log(req.file);
//   });


module.exports = router;