const { response } = require("express");
var express = require("express");

var router = express.Router(); 
const conn = require("../config/DB.js");


router.post('/login', function(req,res,next){  

        console.log('첫 번째 미들웨어 호출 됨');
        var approve ={'approve_id':'NO','approve_pw':'NO'};

        var paramId = req.body.id;
        var paramPassword = req.body.password;
        console.log('id : '+paramId+'  pw : '+paramPassword);

        var sql = "select * from user_info where user_id = ?"

        conn.query(sql,[paramId], function(err, rows){

            if(rows.length>0){

                console.log(rows);

                if(paramId == rows[0].user_id) approve.approve_id = 'OK';
                if(paramPassword == rows[0].user_pw) approve.approve_pw = 'OK';
            
            }else{
                approve.approve_id="not_ex_id";
            }
            res.send(approve); 

        })      
          
    
});
// router.post('/editprofile', function (req, res) {
//     let id = req.body.id;
    

//     let sql = "select user_name, user_tel, user_add from user_info where user_id=?"

//     conn.query(sql, [id], function (err, rows) {
        
//         if (rows.length > 0) {
            
//             console.log(rows);


//         }

//     })
// })


router.post('/join', function (req, res, next) {
    console.log('두번째 라우터 실행');
    console.log(req.body);

    var param_id = req.body.id;
    var param_pw = req.body.pw;
    var param_name = req.body.name;
    var param_tel = req.body.tel;
    var param_add = req.body.add;

    var sql = "insert into user_info value (?,?,?,?,?,0)";

    conn.query(sql, [param_id, param_pw, param_name, param_tel, param_add], function (err, rows) {

        if (err) {
            console.log("insert_fail");
            return response.status(400).send("회원가입 실패");
        }
        console.log("join_success");
        res.sendStatus(200);

    });
});

router.post('/diarywrite', function (req, res, next) {
    console.log("영농일지작성 라우터 실행");
    console.log(req.body);

    let param_date = req.body.diary_date;
    let param_field = req.body.field;
    let param_pest = req.body.pest;
    let param_pest_use = req.body.pest_use;
    let param_water = req.body.water;
    let param_ph = req.body.ph;
    let param_sects = req.body.sects;
    let param_detail = req.body.detail;
    let param_id = req.body.id;
    //let user_id = req.session.user.id;

    console.log(req.body.diary_date)

    let sql = "insert into diary(user_id,diary_date,field,pest,pest_use,water,ph,sects,diary_detail) value(?,?,?,?,?,?,?,?,?)";

    conn.query(sql, [param_id,param_date,param_field, param_pest, param_pest_use, param_water,
        param_ph, param_sects, param_detail], function (err, rows) {
        
        if (err) {
            console.log("데이터 삽입 실패");
            return response.status(400).send("일지작성 실패");
        }
        console.log("일지작성 성공");
        res.status(200);
    });
});

router.post('/profileshow', function (req, res, next) {

    console.log('프로필 보여주기 호출 됨');
    let approve = {'approve_name': 'NO', 'approve_tel': 'NO', 'approve_add': 'NO' };

    let param_id = req.body.id;
    let param_name = req.body.name;
    let param_tel = req.body.tel;
    let param_add = req.body.add;

    console.log( 'name : ' + param_name + 'tel : ' + param_tel + 'add : ' + param_add);

    let sql = "select user_name,user_tel,user_add from user_info where user_id=?"

    conn.query(sql, [param_id], function (err, rows) {

        if (rows.length > 0) {
            console.log(rows);
            approve.approve_name = rows[0].user_name;
            approve.approve_tel = rows[0].user_tel;
            approve.approve_add = rows[0].user_add;
        } else {
            
            approve.approve_name = "not_ex_name";
            approve.approve_tel = "not_ex_tel";
            approve.approve_add = "not_ex_add";
        }
        res.send(approve);
    })
});

router.post('/profileedit', function (req, res, next) {
    console.log("프로필 수정 라우터 호출");
    let approve_name = { 'approve_name': 'NO' };
    let approve_tel = { 'approve_tel': 'NO' };
    let approve_add = { 'approve_add': 'NO' };

    //console.log(req.body);

    let param_id = req.body.id;
    let param_name = req.body.name;
    let param_tel = req.body.tel;
    let param_add = req.body.add;

   
    let sql1 = "update user_info set user_name=? where user_id=?";
    
    

    conn.query(sql1, [param_name, param_id], function (err, rows) {
        //console.log(rows);
        if (rows.length > 0) {
            //console.log(rows);
            approve_name.approve_name = rows[0].user_name;
            res.send(approve_name);
        }
        
        console.log("회원정보수정성공1");
        
    });

    let sql2 = "update user_info set user_tel=? where user_id=?";
    conn.query(sql2, [param_tel, param_id], function (err, rows) {     
        if (rows.length > 0) {
            //console.log(rows);
            approve_tel.approve_tel = rows[0].user_tel;
        }
        console.log("회원정보수정성공2");
        //res.send(approve_tel);
        
    });

    let sql3 = "update user_info set user_add =? where user_id =?";
    conn.query(sql3, [param_add, param_id], function (err, rows) {
        if (rows.length > 0) {
            //console.log(rows);
            approve_add.approve_add = rows[0].user_add;
        }
        console.log("회원정보수정성공3");
        //res.send(approve_add);
    });
});

router.post('/proregister', function (req, res, next) {
    console.log("전문가등록 라우터 실행");
    console.log(req.body);

    // let param_poto = req.body.poto;
    let param_detail = req.body.detail;

    let param_id = req.body.id;
    //let user_id = req.session.user.id;

    let sql = "insert into pro_info(user_id,pro_poto, pro_detail) value(?,null,?);";
    let sql2 = "update user_info set user_pro=1 where user_id=?";
    +
        conn.query(sql, [param_id, param_detail], function (err, rows) {

            if (err) {
                console.log("데이터 삽입 실패");
                return response.status(400).send("전문가등록 실패");
            }
            console.log("전문가등록 성공");
            res.status(200);


        });
        conn.query(sql2, [param_id], function (err, rows) {
        if (err) {
            console.log("데이터 업데이트 실패");
            return response.status(400).send("전문가등록 실패");
        }
        console.log("전문가등록 업데이트 성공");
        res.status(200);
    })
});


router.post('/prolist', function (req, res, next) {

    console.log("전문가 리스트 라우터 실행")
    let approve = { 'approve_name': 'NO', 'approve_tel': 'NO', 'approve_detail': 'NO' };

    let param_name = req.body.name;
    let param_tel = req.body.tel;
    let param_detail = req.body.detail;

    console.log('name : ' + param_name + 'tel : ' + param_tel + 'detail : ' + param_detail)


    let sql = "select u.user_name, u.user_tel, p.pro_detail from user_info as u, pro_info as p where u.user_pro=1 and u.user_id=p.user_id;"

    conn.query(sql, function (err, rows) {
        if (rows.length > 0) {
            console.log(rows);
            approve.approve_name = rows[0].user_name;
            approve.approve_tel = rows[0].user_tel;
            approve.approve_detail = rows[0].pro_detail;
        }
        res.send(approve);
    })
});
    




router.post('/prodetail', function (req, res, next) {
    console.log("전문가 상세정보 라우터 실행");

    console.log(req.body)
    let approve = { 'approve_name': 'NO', 'approve_tel': 'NO', 'approve_add': 'NO' , 'approve_detail': 'NO' };

    let param_name = req.body.pro_name;
    // let param_tel = req.body.tel;
    // let param_add = req.body.add;
    // let param_detail = req.body.detail;
    
    //console.log('name : ' + param_name + 'tel : ' + param_tel + 'add : ' + param_add +'detail : ' + param_detail)

    //let sql = "select u.user_name, u.user_tel, u.user_add, p.pro_detail from user_info as u, pro_info as p where u.user_pro=1 and u.user_id=p.user_id;"
    let sql2 = "select user_info.user_name, user_info.user_tel, user_info.user_add, pro_info.pro_detail from user_info inner join pro_info on user_info.user_id =pro_info.user_id where user_info.user_name = ?";
   
    conn.query(sql2, [param_name],function (err, rows) {

        //console.log(rows)
        
            
        approve.approve_name = rows[0].user_name;
        approve.approve_tel = rows[0].user_tel;
        approve.approve_add = rows[0].user_add;
        approve.approve_detail = rows[0].pro_detail;
    
        console.log(approve)
        res.send(approve);
    })
});



router.post("/diaryShow", function (req, res) {
    
    console.log("다이어리 보여주기 라우터 실행")

    let approve = { 'approve_id': 'NO',  'approve_field': 'NO', 'approve_pest': 'NO', 'approve_pest_use': 'NO', 'approve_water': 'NO', "approve_ph": "NO", "approve_sects": "NO", "approve_detail": "NO" };

    let param_id = req.body.id;
    let param_field = req.body.field;
    let param_pest = req.body.pest;
    let param_pest_use = req.body.pest_use;
    let param_water = req.body.water;
    let param_ph = req.body.ph;
    let param_sects = req.body.sects;
    let param_detail = req.body.detail;
    let param_diary_date = req.body.diary_date;

    console.log(req.body)
    console.log(param_diary_date)
   // console.log(("아이디 : ", param_id));

    //console.log('id: ' + param_id + 'field : ' + param_field + 'pest : ' + param_pest + 'pest_use : ' + param_pest_use + 'water : ' + param_water + 'ph : ' + param_ph + 'sects : ' + param_sects + 'detail : ' + param_detail);

    let sql = "select * from diary where user_id = ? and diary_date=?";

    conn.query(sql, [param_id, param_diary_date], function (err, rows) {
        if (rows.length > 0) {
            console.log(rows[0]);
 
            approve.approve_id = rows[0].user_id;
            approve.approve_diary_date = rows[0].diary_date;
            approve.approve_field = rows[0].field;
            approve.approve_pest = rows[0].pest;
            approve.approve_pest_use = rows[0].pest_use;
            approve.approve_water = rows[0].water;
            approve.approve_ph = rows[0].ph;
            approve.approve_sects = rows[0].sects;
            approve.approve_detail = rows[0].diary_detail;

            console.log(approve)

        } else {
            console.log(err)
        }
        res.send(approve)
    })
});


router.post('/result_list', function (req, res, next) {
    console.log("진단내역 보여주기");
    console.log(req.body);

    var approve_result_list={};
    var approve_dis_info={};

    let param_Login_id = req.body.id;

    let sql = "select dis_name, ins_time from ins_result where user_id = ?";
    let sql2 = "select * from disease_info"

    // approve_dis_name.add="탄저병"
    // approve_dis_name.dis_name = "갈색무늬병"
    // approve_dis_name.dis_name = "과수화상병"
    // console.log(approve_dis_name)
    conn.query(sql, [param_Login_id], function (err, rows) {
        if (err) {console.log("출력실패");}
        console.log("데이터 출력");
        //console.log(rows);

        approve_result_list.all = rows;

        // conn.query(sql2,function(err, rows){
        //     approve_result_list.dis_info = rows
        //     console.log(approve_result_list);

        //     res.send(approve_result_list);
        // });
        // console.log(approve_result_list);
        // console.log(approve_result_list.all[2].ins_time)
        res.send(approve_result_list)
    });
});

router.post('/pro_list', function (req, res, next) {
    console.log("전문가 보여주기");
    console.log(req.body);

    var approve_pro_list={};

    let sql = "select user_info.user_name, user_info.user_tel, pro_info.pro_detail from user_info inner join pro_info on user_info.user_id =pro_info.user_id";

    conn.query(sql,function(err,rows){
        console.log(rows);
        approve_pro_list.all = rows

        res.send(approve_pro_list);
    });
 
});


router.post("/resultShow", function (req, res) {
    
    console.log("결과 보여주기 라우터 실행")
    console.log(req.body)
    let approve = {'approve_inspercent': 'NO', 'approve_disdata': 'NO'};
    let param_id = req.body.id;
    let param_disname = req.body.Dname;
    let param_inspercent = req.body.inspercent;
    let param_disdata = req.body.disdata;
    let param_time = req.body.Date;


    let sql = "select u.user_id, d.dis_name, i.ins_percent, d.dis_data from user_info as u, disease_info as d, ins_result as i where d.dis_name = i.dis_name and u.user_id = i.user_id;"
    let sql2 = "select user_info.user_name, user_info.user_tel, user_info.user_add, pro_info.pro_detail from user_info inner join pro_info on user_info.user_id =pro_info.user_id where user_info.user_name = ?";
    let sql3 = "select ins_result.ins_percent, disease_info.dis_data from ins_result inner join disease_info on ins_result.dis_name = disease_info.dis_name where ins_result.user_id =? and ins_result.dis_name=? and ins_result.ins_time=?";

    conn.query(sql3, [param_id,param_disname,param_time], function (err, rows) {
        if (rows.length > 0) {
            console.log(rows[0]);

            approve.approve_inspercent = rows[0].ins_percent;
            approve.approve_disdata = rows[0].dis_data;
            console.log(approve)

        } else {
            //console.log(err);
        }
        res.send(approve)
    })
});

router.post('/insresult', function (req, res, next) {
    console.log("질병진단결과 라우터 실행");
    console.log(req.body);

    let approve = { 'approve_id': 'NO',  'approve_disname': 'NO', 'approve_poto': 'NO', 'approve_inspercent': 'NO', 'approve_disdata': 'NO' };

    let param_id = req.body.id;
    let ins_poto = req.body.poto;
    let dis_name = req.body.name;
    let ins_percent = req.body.percent;
    let dis_data = req.body.data;
   
    
    //console.log('name : ' + param_name + 'tel : ' + param_tel + 'add : ' + param_add +'detail : ' + param_detail)

    let sql = "select u.user_id, d.dis_name, i.ins_poto, i.ins_percent, d.dis_data from ins_result as i, disease_info as d, user_info as u where i.dis_name = d.dis_name and u.user_id = i.user_id;"
    

    conn.query(sql, function (err, rows) {
        if (rows.length > 0) {


            approve.approve_id = rows[0].user_id;
            approve.approve_disname = rows[0].dis_name;
            approve.approve_poto = rows[0].ins_poto;
            approve.approve_inspercent = rows[0].ins_percent;
            approve.approve_disdata = rows[0].dis_data;
            
            //console.log(rows);
            //console.log(approve)

        }
        res.send(approve);
    })
});




module.exports = router;